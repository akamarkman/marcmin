# MARCmin Phase 1 test kit

Everything needed to rerun the first MARCmin search comparison on your own machine,
including the larger models that did not fit on the machine used for the first run.

## What's inside

- `data/corpus.jsonl`: 3,781 Library of Congress records (English-language books with subject
  headings) from five classes: Q science, R medicine, S agriculture, G geography and recreation,
  N fine arts. Each line holds the record in four formats: `raw` (MARC mnemonic text),
  `full` (pre-encoded), `compact` and `locstyle` (an approximation of the Library of Congress
  embedded catalog's descriptive-fields input).
- `data/questions.jsonl`: 120 draft patron questions, each with the one record (`target`) that
  should answer it. Drafted by an AI assistant from the record; not yet reviewed by a cataloger.
- `data/loc_vectors.npy`: each record's Library of Congress Titan V2 vector, same order as the corpus.
- `data/results.json`: ranks from the first run, for comparison.
- `code/`: the scripts that built and scored all of this.

Source data: Library of Congress "Experimental Embeddings Data by LCC" (id.loc.gov/download),
with full MARCXML fetched by control number from the Library of Congress SRU service, November 2026.

## Run it

Needs Python 3.10+ and about 4 GB of free memory for the largest model.

```
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python code/evaluate.py data "BGE-base (110M)" "BGE-large (335M)"
```

Run all four models with `python code/evaluate.py data`. Embeddings are cached in `data/cache/`,
and every run's ranks and scores are written to `data/results.json`.

## Score the Library of Congress benchmark

With AWS credentials that can use Amazon Bedrock:

```
python code/embed_titan_queries.py data
python code/evaluate.py data "MiniLM-L6 (22M)"
```

The second command adds a "LoC Titan V2 (benchmark)" row to `data/results.json`.

## Rebuild from scratch (optional)

`sample_loc.py` samples the Library of Congress files, `fetch_marc.py` fetches full records,
`build_corpus.py` builds the corpus and `pick_targets.py` lists records to write questions for.

## Caveats

The questions are drafts and probably too easy. The first run's numbers are preliminary
until catalogers review the questions. See marcmin.com for the write-up.
