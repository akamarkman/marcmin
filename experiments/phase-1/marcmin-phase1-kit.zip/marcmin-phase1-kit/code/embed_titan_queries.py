"""Embed the test questions with Amazon Titan Text Embeddings V2, the model behind the
Library of Congress embedded catalog, so the benchmark can be scored.

Needs AWS credentials with Amazon Bedrock access (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY,
AWS_REGION) and `pip install boto3`. Cost for 120 short questions: well under one cent.

Usage: python code/embed_titan_queries.py data
Writes data/titan_queries.npy (one 1,024-dimension row per question, same order as questions.jsonl).
"""
import json, os, sys
import boto3
import numpy as np

kit = sys.argv[1]
qs = [json.loads(l) for l in open(f"{kit}/questions.jsonl")]
client = boto3.client("bedrock-runtime", region_name=os.environ.get("AWS_REGION", "us-east-1"))
vecs = []
for q in qs:
    body = json.dumps({"inputText": q["text"], "dimensions": 1024, "normalize": True})
    r = client.invoke_model(modelId="amazon.titan-embed-text-v2:0", body=body)
    vecs.append(json.loads(r["body"].read())["embedding"])
np.save(f"{kit}/titan_queries.npy", np.asarray(vecs, dtype=np.float32))
print(f"wrote {len(vecs)} question vectors to {kit}/titan_queries.npy")
