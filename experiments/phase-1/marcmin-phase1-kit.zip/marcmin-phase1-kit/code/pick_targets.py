"""Pick question targets for one class (seeded) and print a compact view to write questions from."""
import json, random, sys
sys.path.insert(0, sys.argv[0].rsplit("/", 1)[0])
from pymarc import parse_xml_to_array
from formats import fixed, subjects, compact
raw, c, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
rs = [r for r in parse_xml_to_array(open(f"{raw}/{c}_marc.xml", "rb")) if r]
ok = [r for r in rs if fixed(r)[0] == "English" and fixed(r)[2] == "Book" and subjects(r)]
import gzip
order = [json.loads(l)["lc_001"] for l in gzip.open(f"{raw}/{c}_sample.jsonl.gz")]
pos = {i: k for k, i in enumerate(order)}
ok = sorted(ok, key=lambda r: pos.get(r["001"].data.strip(), 10**9))[:1000]  # same records build_corpus keeps
pool = sorted(ok, key=lambda r: r["001"].data)
picks = random.Random(f"targets-{c}").sample(pool, n)
for r in picks:
    print("### id", r["001"].data.strip())
    print(compact(r, 60)); print()
