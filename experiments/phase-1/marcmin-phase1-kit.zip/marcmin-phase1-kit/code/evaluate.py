"""Run the Phase 1 comparison: record forms x embedding models (+ BM25, + LoC Titan vectors if query vectors exist).

Usage: evaluate.py KIT_DIR [model ...]
Reads KIT/corpus.jsonl, KIT/questions.jsonl, KIT/loc_vectors.npy, optional KIT/titan_queries.npy (rows match questions).
Caches embeddings in KIT/cache/. Writes KIT/results.json.
"""
import gc, json, os, random, sys, time
import torch
import numpy as np

kit = sys.argv[1]
MODELS = {
    "MiniLM-L6 (22M)": ("sentence-transformers/all-MiniLM-L6-v2", ""),
    "BGE-small (33M)": ("BAAI/bge-small-en-v1.5", "Represent this sentence for searching relevant passages: "),
    "BGE-base (110M)": ("BAAI/bge-base-en-v1.5", "Represent this sentence for searching relevant passages: "),
    "BGE-large (335M)": ("BAAI/bge-large-en-v1.5", "Represent this sentence for searching relevant passages: "),
}
wanted = sys.argv[2:] or list(MODELS)
FORMS = ["raw", "full", "compact", "locstyle"]
docs = [json.loads(l) for l in open(f"{kit}/corpus.jsonl")]
qs = [json.loads(l) for l in open(f"{kit}/questions.jsonl")]
idx = {d["id"]: i for i, d in enumerate(docs)}
targets = np.array([idx[q["target"]] for q in qs])
os.makedirs(f"{kit}/cache", exist_ok=True)

def ranks(scores):
    # rank (1-based) of each question's target
    t = scores[np.arange(len(qs)), targets]
    return (scores > t[:, None]).sum(1) + 1

def metrics(r):
    r = np.asarray(r)
    return {"mrr10": float(np.mean(np.where(r <= 10, 1.0 / r, 0))), "r1": float(np.mean(r == 1)), "r10": float(np.mean(r <= 10)), "median_rank": float(np.median(r))}

results = json.load(open(f"{kit}/results.json")) if os.path.exists(f"{kit}/results.json") else {"runs": {}}
from rank_bm25 import BM25Okapi
import re
tok = lambda s: re.findall(r"[a-z0-9$]+", s.lower())
for form in ("raw", "full"):
    bm = BM25Okapi([tok(d[form]) for d in docs])
    sc = np.array([bm.get_scores(tok(q["text"])) for q in qs])
    results["runs"][f"BM25 keyword | {form}"] = {"ranks": ranks(sc).tolist()}

from sentence_transformers import SentenceTransformer
for name in wanted:
    mid, qp = MODELS[name]
    m = SentenceTransformer(mid, device="cpu")
    if "large" in mid:
        m = m.to(torch.bfloat16)  # halves memory; noted in the write-up
    qv = m.encode([qp + q["text"] for q in qs], normalize_embeddings=True, batch_size=8)
    for form in FORMS:
        cp = f"{kit}/cache/{mid.replace('/', '_')}__{form}.npy"
        if os.path.exists(cp):
            dv = np.load(cp); secs = results["runs"].get(f"{name} | {form}", {}).get("encode_seconds")
        else:
            t0 = time.time(); parts = []
            texts = [d[form] for d in docs]
            for i in range(0, len(texts), 200):  # small chunks keep memory low on a shared machine
                with torch.inference_mode():
                    parts.append(m.encode(texts[i:i + 200], normalize_embeddings=True, batch_size=8).astype(np.float32))
                gc.collect()
            dv = np.concatenate(parts); secs = time.time() - t0
            np.save(cp, dv)
        ntok = float(np.mean([len(m.tokenizer(d[form])["input_ids"]) for d in docs[:500]]))
        results["runs"][f"{name} | {form}"] = {"ranks": ranks(qv @ dv.T).tolist(), "encode_seconds": secs, "avg_tokens": ntok, "max_tokens": m.max_seq_length}
        print(name, form, metrics(results["runs"][f"{name} | {form}"]["ranks"]), flush=True)
        json.dump(results, open(f"{kit}/results.json", "w"))

if os.path.exists(f"{kit}/titan_queries.npy"):
    lv = np.load(f"{kit}/loc_vectors.npy"); lv /= np.linalg.norm(lv, axis=1, keepdims=True)
    tq = np.load(f"{kit}/titan_queries.npy"); tq /= np.linalg.norm(tq, axis=1, keepdims=True)
    results["runs"]["LoC Titan V2 (benchmark) | loc"] = {"ranks": ranks(tq @ lv.T).tolist()}

for k, v in results["runs"].items():
    v.update(metrics(v["ranks"]))
results["n_docs"], results["n_questions"] = len(docs), len(qs)
json.dump(results, open(f"{kit}/results.json", "w"), indent=1)
print("done")
