"""Build the Phase 1 corpus: filter fetched records, keep up to N per class, store four text forms + LoC vectors."""
import gzip, json, sys
import numpy as np
from pymarc import parse_xml_to_array
sys.path.insert(0, sys.argv[0].rsplit("/", 1)[0])
from formats import FORMS, fixed, subjects

raw, out, classes, per = sys.argv[1], sys.argv[2], sys.argv[3].split(","), int(sys.argv[4])
docs, vecs = [], []
for c in classes:
    emb = {}
    order = []
    for l in gzip.open(f"{raw}/{c}_sample.jsonl.gz"):
        d = json.loads(l); emb[d["lc_001"]] = d; order.append(d["lc_001"])
    recs = {r["001"].data.strip(): r for r in parse_xml_to_array(f"{raw}/{c}_marc.xml") if r and r.get("001")}
    kept = 0
    for i in order:
        r = recs.get(i)
        if r is None:
            continue
        lang, year, t, aud, form = fixed(r)
        if lang != "English" or t != "Book" or not subjects(r):
            continue
        d = {"id": i, "class": c, "lccn": emb[i]["meta"].get("LCCN"), "lcc": emb[i]["meta"].get("LCCCode"),
             "loc_meta": emb[i]["meta"], **{k: f(r) for k, f in FORMS.items()}}
        docs.append(d); vecs.append(emb[i]["embedding"]); kept += 1
        if kept >= per:
            break
    print(f"{c}: {len(recs)} records fetched, {kept} kept")
with open(f"{out}/corpus.jsonl", "w") as f:
    for d in docs:
        f.write(json.dumps(d, ensure_ascii=False) + "\n")
np.save(f"{out}/loc_vectors.npy", np.asarray(vecs, dtype=np.float32))
print(len(docs), "documents")
