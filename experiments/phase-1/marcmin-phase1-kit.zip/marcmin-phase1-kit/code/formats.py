"""Four text forms of a MARC record, for the MARCmin Phase 1 comparison."""
import re

LANG = {"eng": "English", "spa": "Spanish", "fre": "French", "ger": "German", "ita": "Italian", "por": "Portuguese",
        "chi": "Chinese", "jpn": "Japanese", "kor": "Korean", "rus": "Russian", "ara": "Arabic", "heb": "Hebrew",
        "vie": "Vietnamese", "dut": "Dutch", "pol": "Polish", "swe": "Swedish", "dan": "Danish", "nor": "Norwegian",
        "cze": "Czech", "hun": "Hungarian", "gre": "Greek", "tur": "Turkish", "hin": "Hindi", "per": "Persian",
        "lat": "Latin", "fin": "Finnish", "rum": "Romanian", "ukr": "Ukrainian", "tha": "Thai", "ind": "Indonesian",
        "mul": "Multiple languages", "und": "Undetermined"}
TYPE = {"a": "Book", "c": "Printed music", "d": "Manuscript music", "e": "Map", "f": "Manuscript map", "g": "Video or slides",
        "i": "Audio (spoken word)", "j": "Music recording", "k": "Image", "m": "Computer file", "o": "Kit", "p": "Mixed materials",
        "r": "Object", "t": "Manuscript"}
AUD = {"a": "Preschool", "b": "Primary school", "c": "Children", "d": "Teens", "e": "Adult", "f": "Specialized", "g": "General", "j": "Children and teens"}
ABBR = [(r"\bp\.", "pages"), (r"\bill\.", "illustrations"), (r"\bcol\.", "color"), (r"\bed\.", "edition"),
        (r"\bv\.", "volumes"), (r"\bports?\.", "portraits"), (r"\bmaps?\.", "maps"), (r"\bfacsims?\.", "facsimiles"),
        (r"\bincl\.", "including"), (r"\bbibliog\.", "bibliography"), (r"\brev\.", "revised"), (r"\bca\.", "about")]
SKIP = set("012456789")  # identifiers, sources, relator codes, linkage


def clean(v):
    return re.sub(r"\s+", " ", v).strip().rstrip(" /:;,=").rstrip(".").strip()


def expand(v):
    for p, w in ABBR:
        v = re.sub(p, w, v)
    return v


def subs(f, codes=None, skip=SKIP):
    return [clean(expand(s.value)) for s in f.subfields if (codes is None or s.code in codes) and s.code not in skip and clean(s.value)]


def title(r):
    f = r.get("245")
    return ": ".join(subs(f, "abnp")) if f else ""


def names(r, tags):
    out = []
    for f in r.get_fields(*tags):
        n = " ".join(subs(f, "abcdq"))
        roles = [clean(s.value) for s in f.subfields if s.code == "e"]
        out.append(f"{n} ({', '.join(roles)})" if roles else n)
    return out


def subjects(r):
    out = []
    for f in r.get_fields("600", "610", "611", "630", "650", "651"):
        s = " — ".join(subs(f, "abcdtvxyz"))
        if s and s not in out:
            out.append(s)
    return out


def fixed(r):
    f008 = r.get("008")
    d = f008.data if f008 else ""
    lang = LANG.get(d[35:38], d[35:38].strip()) if len(d) > 37 else ""
    year = d[7:11] if len(d) > 10 and d[7:11].strip().isdigit() else ""
    t = TYPE.get(r.leader[6], "") if r.leader else ""
    aud = AUD.get(d[22], "") if len(d) > 22 and t in ("Book", "Video or slides", "Audio (spoken word)") else ""
    lf = d[33] if len(d) > 33 and t == "Book" else ""
    form = {"0": "Nonfiction", "1": "Fiction", "f": "Fiction", "j": "Short stories", "p": "Poetry", "d": "Drama", "e": "Essays"}.get(lf, "")
    return lang, year, t, aud, form


def published(r):
    for f in r.get_fields("264", "260"):
        if f.tag == "264" and f.indicator2 not in ("1", " "):
            continue
        p = subs(f, "abc")
        if p:
            return ", ".join(p)
    return ""


def raw(r):
    """What an unprepared pipeline embeds: the full record in mnemonic form."""
    return str(r)


def full(r):
    lang, year, t, aud, form = fixed(r)
    lines = []
    def add(label, v):
        if v:
            lines.append(f"{label}: {v}")
    add("Title", title(r))
    add("By", "; ".join(names(r, ("100", "110", "111"))))
    add("Contributors", "; ".join(names(r, ("700", "710", "711"))))
    add("Edition", "; ".join(" ".join(subs(f)) for f in r.get_fields("250")))
    add("Published", published(r))
    add("Description", "; ".join(" ".join(subs(f, "abc")) for f in r.get_fields("300")))
    add("Series", "; ".join(" ".join(subs(f, "av")) for f in r.get_fields("490", "830")))
    add("Subjects", "; ".join(subjects(r)))
    add("Genre", "; ".join(dict.fromkeys(" ".join(subs(f, "avxyz")) for f in r.get_fields("655"))))
    add("Summary", " ".join(" ".join(subs(f, "ab")) for f in r.get_fields("520")))
    add("Contents", " ".join(" ".join(subs(f, "agrt")) for f in r.get_fields("505")))
    add("Notes", " ".join(" ".join(subs(f, "a")) for f in r.get_fields("500", "504")))
    add("Format", ", ".join(x for x in (t, form) if x))
    add("Language", lang)
    add("Audience", aud)
    add("Year", year)
    return "\n".join(lines)


def compact(r, max_words=40):
    lang, year, t, aud, form = fixed(r)
    summ = " ".join(" ".join(subs(f, "a")) for f in r.get_fields("520")).split()
    parts = [("Title", title(r)), ("By", "; ".join(names(r, ("100", "110", "111")))), ("Subjects", "; ".join(subjects(r))),
             ("Summary", " ".join(summ[:max_words]) + (" …" if len(summ) > max_words else "")),
             ("Format", ", ".join(x for x in (t, form) if x)), ("Language", lang), ("Audience", aud), ("Year", year)]
    return "\n".join(f"{k}: {v}" for k, v in parts if v)


def locstyle(r):
    """Approximation of the Library of Congress embedded catalog's input: descriptive fields only
    (title, subject headings, classification, summary, contents, notes), unlabeled. The exact format
    LoC used is not published."""
    vals = [title(r)] + subjects(r)
    vals += [" ".join(s.value for s in f.subfields if s.code in "ab") for f in r.get_fields("050")]
    for tag in ("520", "505", "500", "504"):
        vals += [" ".join(subs(f)) for f in r.get_fields(tag)]
    return " ".join(v for v in vals if v)


FORMS = {"raw": raw, "full": full, "compact": compact, "locstyle": locstyle}
