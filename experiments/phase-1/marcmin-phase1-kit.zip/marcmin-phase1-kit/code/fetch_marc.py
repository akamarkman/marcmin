"""Fetch full MARCXML for sampled Library of Congress entries by control number (001) via SRU.

Reads RAW/<CLASS>_sample.jsonl.gz, writes RAW/<CLASS>_marc.xml (one <collection>, the records as returned).
"""
import gzip, json, re, sys, time, urllib.parse, urllib.request

raw, classes = sys.argv[1], sys.argv[2].split(",")
SRU = "https://lx2.loc.gov/sru/lcdb?version=1.1&operation=searchRetrieve&recordSchema=marcxml&maximumRecords=50&query="
for c in classes:
    ids = [json.loads(l)["lc_001"] for l in gzip.open(f"{raw}/{c}_sample.jsonl.gz")]
    recs = []
    for i in range(0, len(ids), 10):
        q = " or ".join(f"rec.id={x}" for x in ids[i:i + 10])
        url = SRU + urllib.parse.quote(q)
        for attempt in range(4):
            try:
                body = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (MARCmin research)"}), timeout=60).read().decode("utf-8")
                break
            except Exception as e:
                print(c, i, "retry", e, flush=True); time.sleep(5 * (attempt + 1))
        else:
            raise SystemExit(f"failed batch {c} {i}")
        recs += re.findall(r"<record xmlns=\"http://www.loc.gov/MARC21/slim\">.*?</record>", body, re.S)
        time.sleep(0.5)
    with open(f"{raw}/{c}_marc.xml", "w") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<collection xmlns="http://www.loc.gov/MARC21/slim">\n' + "\n".join(recs) + "\n</collection>\n")
    print(f"{c}: {len(ids)} requested, {len(recs)} records fetched", flush=True)
