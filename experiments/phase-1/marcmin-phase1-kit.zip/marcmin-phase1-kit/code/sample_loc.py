"""Reservoir-sample entries from the Library of Congress embedded-catalog files (one per LCC class).

Streams https://lds-downloads.s3.amazonaws.com/embeddings/<CLASS>_embeddings_2025.jsonl.gz,
keeps N raw lines per class (seeded), writes them gzipped to OUT/<CLASS>_sample.jsonl.gz.
"""
import gzip, json, random, sys, time, urllib.request

classes, n, out = sys.argv[1].split(","), int(sys.argv[2]), sys.argv[3]
for c in classes:
    url = f"https://lds-downloads.s3.amazonaws.com/embeddings/{c}_embeddings_2025.jsonl.gz"
    rng, keep, seen, t0 = random.Random(f"marcmin-{c}"), [], 0, time.time()
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as r, gzip.GzipFile(fileobj=r) as g:
        for line in g:
            seen += 1
            if len(keep) < n:
                keep.append(line)
            else:
                j = rng.randrange(seen)
                if j < n:
                    keep[j] = line
            if seen % 100000 == 0:
                print(f"{c}: {seen} read, {time.time()-t0:.0f}s", flush=True)
    with gzip.open(f"{out}/{c}_sample.jsonl.gz", "wb") as f:
        f.writelines(keep)
    print(f"{c}: done, {seen} entries in class, kept {len(keep)}, {time.time()-t0:.0f}s", flush=True)
    with open(f"{out}/class_counts.tsv", "a") as f:
        f.write(f"{c}\t{seen}\t{url}\t{time.strftime('%Y-%m-%d')}\n")
